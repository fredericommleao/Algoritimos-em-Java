import java.util.Scanner;

public class exercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner (System.in) ;

		System.out.println("Digite a quantidade de elementos :");
		int n = in.nextInt();
	
		int [] vetor ; vetor = new int [n] ;
		int pares = 0 ;
		for(int i = 0 ; i < vetor.length ; i++)
		{
			vetor[i] = in.nextInt();	
			
			if(vetor[i]%2 == 0)
				{
				pares = pares + 1 ;	
				}
			
		}
		//========================================================//
		System.out.println("Quantidade de pares igual a "+pares);
		for(int i = 0 ; i < vetor.length ; i ++)
		{
				
			if(vetor[i]%2 == 0)
			{
			System.out.println("Valor par: "+vetor[i]);	
				
			}
			
			
			 
		}
	
	
	}

}
