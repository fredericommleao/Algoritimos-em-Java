import java.util.Scanner;

public class exercicio1e2a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner in = new Scanner (System.in) ;
		System.out.println("Digite a quantidade de �ndices:");
		int n = in.nextInt();
		int [] A ; A = new int [n] ;
	
		for(int i = 0 ; i < A.length ; i++)
		{

		System.out.println("Digite o elemento: "+i);
		A[i] = in.nextInt();
			
		}
		
		System.out.println("Digite o valor de X ");
		int X = in.nextInt();

		for(int i = 0 ; i < A.length ; i++)
		{
			if(X == A[i]) 
			{
			
			
			System.out.println("O X igual a "+X+" � igual ao vetorA no �ndice "+i);	
				
			}
			
			
		}
	
			
	
	
	}
}
