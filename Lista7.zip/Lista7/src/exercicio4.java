import java.util.Scanner;

public class exercicio4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner (System.in) ;
		
		char repeti��o = 's' ; 
		while(repeti��o == 's' || repeti��o == 'S') {
		
		System.out.println("Determine a quantidade de �ndices nos vetores : ");
		int n = in.nextInt();
		
			int [] A ; A = new int [n] ;
			int [] B ; B = new int [n] ;
		
			for(int i = 0 ; i < A.length ; i++){
			
			System.out.println("Digite o valor de A[] no �ndice "+i+"� ");	
			A[i] = in.nextInt();	
		
			}
	
			for(int i = 0 ; i < A.length ; i++) {
				
				System.out.println("A[] igual a "+A[i]+" na posi��o "+i+"�");
				
			}
			System.out.println("-------------------------------------------");
			for(int i = 0 ; i < A.length ; i++) {
				
				B[i] = A[i] ;
				n = n - i -1;
				System.out.println("B[] igual a "+B[i]+" na posi��o "+n+"�");	
				
			}
			
			
			
			
			
			
		System.out.println();
		System.out.println("Deseja repetir novamente ? ");
		repeti��o = in.next().charAt(0);
		}
			System.out.println("Programa encerrado");

	
	
	}
}
