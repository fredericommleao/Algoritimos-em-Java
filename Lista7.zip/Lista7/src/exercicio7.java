import java.util.Scanner;

public class exercicio7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner (System.in) ;

		System.out.println("Digite a quantidade de notas :");
		int n = in.nextInt();
	
		float [] notas ; notas = new float [n] ;	float media = 6 ;
		
		for(int i = 0 ; i < notas.length ; i++) {
			
			System.out.println("Digite a nota do aluno "+i);
			notas[i] = in.nextFloat();
			
		}
			System.out.println("--------------------------------------------------");
			System.out.println("M�dia igual a 6 ");
			System.out.println();
		
		for(int i = 0 ; i < notas.length ; i++) {
			
			if(notas[i]>=media) {
				
			System.out.println("Nota do aluno que ficou acima da m�dia : "+notas[i]);	
				
			}
		}

	
	}
}
