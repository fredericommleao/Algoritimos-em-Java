import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner in = new Scanner (System.in) ;
		
		System.out.println("Digite a quantidade de elementos : ");
		int n = in.nextInt();
		
		int [] vetorA ; vetorA = new int [n] ;
		int [] vetorB ; vetorB = new int [n] ;
		int [] vetorC ; vetorC = new int [n] ;
		System.out.println();
		System.out.println("====== vetor A ====================");
		for(int i = 0 ; i < vetorA.length; i++)
		{
			System.out.println("Elemento n�mero : "+i);
			vetorA[i] = in.nextInt();	
			
		}
		System.out.println();
		
		System.out.println("====== vetor B ====================");
		for(int i = 0 ; i < vetorA.length; i++)
		{
			System.out.println("Elemento n�mero : "+i);
			vetorB[i] = in.nextInt();	
			
		}
		/*
		 * Calculo_da_multiplica��o
		 */
		
		for(int i = 0 ; i < vetorA.length; i++)
		{
			vetorC[i] = vetorA[i] * vetorB[i] ;
			
		}
		System.out.println("================ vetor C ==========");
		System.out.println("====== RESULTADO ==================");
		System.out.println();
		for(int i = 0 ; i < vetorA.length; i++)
		{
		System.out.println("Posi��o : "+i+" igual a "+vetorC[i]);	
			
			
		}
	
	}
}
