import java.util.Scanner;

public class exercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner (System.in) ;

		int menor = 0 ;	int posi��o = 0 ;
		
		System.out.println("Digite a quantidade de �ndices : ");
		int n = in.nextInt();	int a = 0 ;
		
		int [] vetor10 ; vetor10 = new int [n] ;
		
		for(int i = 0 ; i < vetor10.length ; i++) {
		System.out.println("Digite o valor do vetor na posi��o: "+i);	
		vetor10[i] = in.nextInt();
		
		}
		menor = vetor10[0] ;
		for(int i = 0 ; i < vetor10.length ; i++) 
		{
		posi��o = i ;	
		if(menor > vetor10[i]) {
			a = posi��o ;
			menor = vetor10[i] ;
			
			}	
		}
	
		System.out.println("menor n�mero digitado: "+menor);
		System.out.println("Posi��o do menor n�mero digitado: "+a);
	}
}
